## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:long_feedback
- long feedback
- start feedback
- give feedback
- begin feedback
