## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:main_menu
- Let's see
- Main menu
- menu

## intent:plan_my_trip
- Plan My Trip
- plan my tip
- PLAN MY TRIP

## intent:activities_offered
- Activities Offered
- activities offered
- activities
- Activities

## intent:more_info_zipline_tour
- More Information
- About Zipline Tour
- zipline tour

## intent:more_info_natural_exploration
- More Information
- About Natural Exploration
- about natural exploration

## intent:more_info_subwing
- More Information
- About subwing
- subwing

## intent:tour_details_zipline
- Tour details
- Tour details zipline tour

## intent:tour_details_natural_exploration
- Tour Details
- tour details natural exploration


## intent:tour_details_subwing
- Tour Details
- tour details subwing

## intent:add_to_mytrip
- Add to My trip
- add to my trip

## intent:contact_us
- Contact Us
- contact us

## intent:testimonials
- Testimonials
- testimonials
- TESTIMONIALS

## intent:about_costa_rica
- About Costa Rica
- costa rica
- about costa rica

## intent:tips_and_tricks
- Tips And Tricks
- tips and tricks

## intent:tips_1
- Tips1
- tips1

## intent:tips_2
- Tips1
- tips1

## intent:tips_3
- Tips3
- tips3

## intent:other_activities
- Other Activities
- other activities
- OTHER ACTIVITIES