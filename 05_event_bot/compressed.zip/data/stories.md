## happy path
* greet
  - utter_greet
  - utter_welcome_message

## venues_batmanroom1
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* batman_room_confrence
  - action_batman_rooom_details
* view_information
  - utter_view_information

## venues_batmanroom2
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* batman_room_confrence
  - action_batman_rooom_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information 


## venues_supermanroom1
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* superman_room_confrence
  - action_superman_rooom_details
* view_information
  - utter_view_information 

## venues_supermanroom2
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* superman_room_confrence
  - action_superman_rooom_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information 


## venues_heroroom1
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* hero_room_confrence
  - action_hero_rooom_details
* view_information
  - utter_view_information 

## venues_heroroom2
* greet
  - utter_greet
  - utter_welcome_message
* venues_confrence
  - action_venu_confrence_details
* hero_room_confrence
  - action_hero_rooom_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information

## speaker_andrewking01
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* view_session_speaker1
  - action_speakerone_details
* view_information
  - utter_view_information

## speaker_andrewking02
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* view_session_speaker1
  - action_speakerone_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information    

## speaker_daniel01
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* view_session_speaker2
  - action_speakertwo_details
* view_information
  - utter_view_information

## speaker_daniel02
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* view_session_speaker2
  - action_speakertwo_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information     

## speaker_rose01
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* session_speaker3
  - action_speaker_confrence_more_details
* session_rosestone
  - action_speaker_rosestone_details
* view_information
  - utter_view_information 

## speaker_rose02
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* session_speaker3
  - action_speaker_confrence_more_details
* session_rosestone
  - action_speaker_rosestone_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information  

## speaker_frey01
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* session_speaker3
  - action_speaker_confrence_more_details
* session_freyabruke
  - action_speaker_freya_details
* view_information
  - utter_view_information 

## speaker_frey02
* greet
  - utter_greet
  - utter_welcome_message
* speakers_confrence
  - action_speaker_confrence_details
* session_speaker3
  - action_speaker_confrence_more_details
* session_freyabruke
  - action_speaker_freya_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information   


## session_one_details01
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_one_speaker_details
  - action_session_speaker_confrence_details
* view_information
  - utter_view_information 

## session_one_details02
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_one_speaker_details
  - action_session_speaker_confrence_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information         

## session_two_details01
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_two_speaker
  - action_session_two_speaker_confrence_details
* view_information
  - utter_view_information    

## session_two_details02
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_two_speaker
  - action_session_two_speaker_confrence_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information   

## session_three_details02
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_speaker3
  - action_session_more_confrence_details    
* session_one_speaker_details
 - action_session_two_speaker_confrence_details
* view_information
  - utter_view_information    

## session_three_details01
* greet
  - utter_greet
  - utter_welcome_message
* session_confrence
  - action_session_confrence_details
* session_speaker3
  - action_session_more_confrence_details    
* session_one_speaker_details
 - action_session_two_speaker_confrence_details
* subsctibition_to_update
  - utter_subscribe_message
* view_information
  - utter_view_information  


