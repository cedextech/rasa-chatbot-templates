## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:goodbye
- bye
- goodbye
- see you around
- see you later

## intent:venues_confrence
- venues
- Venues
- VENUES

## intent:batman_room_confrence
- View Session
- batman room
- Batman Room

## intent:view_information
- view info
- View Information
- View Info
- view information

## intent:subsctibition_to_update
- Subscribe to update
- subsribe to update
- SUBCRIBE TO UPDATE

## intent:superman_room_confrence
- View Session
- Superman Room
- superman room

## intent:hero_room_confrence
- View Session
- Hero Room
- hero room

## intent:speakers_confrence
- Speakers
- speakers
- SPEAKERS
- Speakeres
- Speakers

## intent:view_session_speaker1
- View Session
- view session
- View session
- VIEW SESSION
- Andrew King

## intent:view_session_speaker2
- View Session
- view session
- View session
- VIEW SESSION
- Daniel Evanas

## intent:session_speaker3
- Show More
- show more
- Rose Stone
- rose stone

## intent:session_rosestone
- View Session
- Session Of Rose Stone
- rose stone session

## intent:session_freyabruke
- View Session
- Session Of Freya Bruke
- freya bruke session

## intent:session_confrence
- Session
- session
- SESSION
- Show Session

## intent:session_one_speaker_details
- View Speakers
- view speakers
- session speakers
- session chatbot with dialogflow

## intent:session_two_speaker
- View Speakers
- view speaker
- session chatbot in 2018













