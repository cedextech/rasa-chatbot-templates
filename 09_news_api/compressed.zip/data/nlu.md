## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:news_headline
- News Headline
- news headline
- News Headlines
- news headlines

## intent:news_us
- News Headline US
- news headline us
- us news headlines

## intent:news_india
- News Headline India
- news headline india
- india news headline

## intent:news_australia
- News Headline Australia
- news headline Australia
- Australia news headline

## intent:news_from_source
- NEWS from Specefic Source
- news from specefic source

## intent:bbc_news
- BBC NEWS
- bbc news
- BBC news

## intent:abc_news
- ABC NEWS
- abc news
- ABC news

## intent:cnn_news
- CNN NEWS
- cnn news

## intent:search_news
- Search News
- search news
