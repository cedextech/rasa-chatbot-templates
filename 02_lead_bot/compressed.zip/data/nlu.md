## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent:accept
- yes
- right
- ok
- okay
- sure
- fine
- it's ok
- it is okay
- of cause
- ofcause

## intent:reject
- no
- don't
- dont
- do not
- please no
- no please
- never
- don't do

## intent:begin_lead
- begin lead
- Web Application Development
- Mobile App Development
- Chatbot Development
- Frontend Development
- Progessive Web App Development
- AI & Machine Learning