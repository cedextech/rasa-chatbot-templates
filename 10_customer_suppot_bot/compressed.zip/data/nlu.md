## intent:greet
- hey
- hello
- hi
- good morning
- good evening
- hey there

## intent: show_all_tickets
- Show All Tickets
- show all tickets
- SHOW ALL TICKETS

## intent: create_ticket
- Create Tickets
- create tickets

## intent: update_ticket
- Update Ticket
- update ticket

