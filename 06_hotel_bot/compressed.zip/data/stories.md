## marine_nearestattra
* greet
 - utter_greet
* nearest_attraction
 - action_nearest_attractions
* marine_drive
 - utter_marine

## mattanche_nearestattra
* greet
 - utter_greet
* nearest_attraction
 - action_nearest_attractions
* mattancherry
 - utter_mattancherry

## fortkochi_nearestattra
* greet
 - utter_greet
* nearest_attraction
 - action_nearest_attractions
* fort_kochi
 - utter_fortkochi

## book_room_dulex_details
* greet
 - utter_greet
* book_rooms
 - action_book_rooms
* dulex_room_details
 - utter_dulexroom_details

## book_room_juniorsuite_details
* greet
 - utter_greet
* book_rooms
 - action_book_rooms
* junior_suite_details
 - utter_juniorsuite_details

## book_room_clubsuitesuite_details
* greet
 - utter_greet
* book_rooms
 - action_book_rooms
* club_suite_details
 - utter_clubsuite_details

## book_room_now
* greet
 - utter_greet
* book_rooms
 - action_book_rooms
* book_room_now
 - book_room_form 
 - action_book_rooms_details

## faqbreakfastmenu
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqbreakfast
 - utter_faqbreakfast

## cancellationplicyfaq
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqcancellationpolicy
 - utter_cancellationpolicy  

## faqcheckin
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqcheckin
 - utter_checkintime

## faqminimumage
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqcheckinage
 - utter_miminumage

## faqcheckouttime
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqcheckout
 - utter_checkout 

## faqchildrenage
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqchildrenage
 - utter_childrenage

## faqearlycheckin
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqearlycheckin
 - utter_earlycheckin

## faqlatecheckin
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqlatecheckin
 - utter_latecheckin

## faqlatecheckout
* faqlatecheckout
 - utter_latecheckout

## faqroomcountdetails
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqroomcount
 - utter_roomcount

## babycotfaq
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqbabycot
 - utter_babycot

## breakfasttime
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqbreakfasttime
 - utter_breakfasttime

## refundpolicy
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqrefundable
 - utter_refundable

## receptiontime
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqreceptiontime
 - utter_receptiontime 

## carparking:
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqparking
 - utter_carparking 

## parkingcost
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqparkingcost
 - utter_parkingcost 

## faqpartialcancel
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqpartialcancel
 - utter_partialcancel

## petpolicyfaq
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqpetpolicy
 - utter_petpolicy

## reservationconfirm
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqreservaconfirm
 - utter_reservationconfirm

## nearestairportfaq
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqnearestairport
 - utter_nearestairport

## modifyreservation
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqmodifyreservation
 - utter_modifyreservation 

## meetingroom
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqmeetingroom 
 - utter_meetingroom

## security
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqsecurity 
 - utter_security

## luggahes
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqluggage 
 - utter_luggage 

## contactnumber
* greet
 - utter_greet
* faq
 - utter_faq_prompt 
* faqcontactnumber 
 - utter_contactnumber  